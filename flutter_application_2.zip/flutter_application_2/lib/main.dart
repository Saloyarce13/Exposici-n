import 'dart:math';
import 'package:flutter/material.dart';

void main() => runApp(const ImplicitAlignApp());

class ImplicitAlignApp extends StatefulWidget {
  const ImplicitAlignApp({super.key});

  @override
  State<ImplicitAlignApp> createState() => _ImplicitAlignAppState();
}

class _ImplicitAlignAppState extends State<ImplicitAlignApp> {
  Alignment _alignment = Alignment.center; // posición inicial

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(title: const Text('Animación Implícita - Movimiento aleatorio')),
        body: Center(
          child: Container(
            width: 300,
            height: 300,
            color: Colors.grey[300],
            child: AnimatedAlign(
              alignment: _alignment,
              duration: const Duration(seconds: 1),
              curve: Curves.easeInOut,
              child: Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: Colors.blueAccent,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
          ),
        ),
        floatingActionButton: FloatingActionButton(
          child: const Icon(Icons.play_arrow),
          onPressed: () {
            final random = Random();

            setState(() {
              // valores aleatorios entre -1 y 1 en X y Y
              double x = (random.nextDouble() * 2) - 1;
              double y = (random.nextDouble() * 2) - 1;
              _alignment = Alignment(x, y);
            });
          },
        ),
      ),
    );
  }
}